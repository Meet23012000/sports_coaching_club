﻿using SportsClub.DAL;
using SportsClub.ENT;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlTypes;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for PlayerBALBase
/// </summary>
/// 
namespace SportscClub.BAL
{
    public abstract class PlayerBALBase
    {
        #region Local Variable

        protected string _Message;

        public String Message
        {
            get
            {
                return _Message;
            }
            set
            {
                _Message = value;
            }
        }
        #endregion Local Variable

        #region Insert Oprations 

        public Boolean Insert(PlayerENT entPlayer)
        {
            PlayerDAL playerDAL = new PlayerDAL();
            if (playerDAL.Insert(entPlayer))
            {
                return true;
            }
            else
            {
                this._Message = playerDAL.Message;
                return false;   
            }
        }

        #endregion Insert Oprations

        #region Update Oprations

        public Boolean Update(PlayerENT entPlayer)
        {
            PlayerDAL playerDAL = new PlayerDAL();
            if (playerDAL.Update(entPlayer))
            {
                return true;
            }
            else
            {
                this._Message = playerDAL.Message;
                return false;
            }
        }

        #endregion Update Oprations

        #region Delete Oprations

        public Boolean Delete(SqlInt32 PlayerID)
        {
            PlayerDAL playerDAL = new PlayerDAL();
            if (playerDAL.Delete(PlayerID))
            {
                return true;
            }
            else
            {
                this._Message = playerDAL.Message;
                return false;
            }
        }

        #endregion Delete Oprations

        #region Select Oprations

        public DataTable SelectAll()
        {
            PlayerDAL dalPlayer = new PlayerDAL();
            return dalPlayer.SelectAll();
        }

        public PlayerENT SelectByPK(SqlInt32 PlayerID)
        {
            PlayerDAL dalPlayer = new PlayerDAL();
            return dalPlayer.SelectByPK(PlayerID);
        }

        public DataTable SelectDropDownList()
        {
            PlayerDAL dalPlayer = new PlayerDAL();
            return dalPlayer.SelectDropDownList();
        }


        #endregion Select Oprations
    }
}