﻿using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for PlayerENTBase
/// </summary>
/// 
namespace SportsClub.ENT
{
    public abstract class PlayerENTBase
    {
        protected SqlInt32 _PlayerID;
        public SqlInt32 PlayerID
        {
            get
            {
                return _PlayerID;
            }
            set
            {
                _PlayerID = value;
            }
        }

        protected SqlString _PlayerName;
        public SqlString  PlayerName
        {
            get
            {
                return _PlayerName;
            }
            set
            {
                _PlayerName = value;
            }
        }

        protected SqlString _PlayerFullName;
        public SqlString  PlayerFullName
        {
            get
            {
                return _PlayerFullName;
            }
            set
            {
                _PlayerFullName = value;
            }
        }

        protected SqlString _MobileNO;
        public SqlString MobileNO
        {
            get
            {
                return _MobileNO;
            }
            set
            {
                _MobileNO = value;
            }
        }

        protected SqlString _Address;
        public SqlString  Address
        {
            get
            {
                return _Address;
            }
            set
            {
                _Address = value;
            }
        }


        protected SqlString _Email;
        public SqlString  Email
        {
            get
            {
                return _Email;
            }
            set
            {
                _Email = value;
            }
        }

        protected SqlInt32 _CoachID;
        public SqlInt32  CoachID
        {
            get
            {
                return _CoachID;
            }
            set
            {
                _CoachID = value;
            }
        }

        protected SqlDateTime _JoiningDate;
        public SqlDateTime  JoiningDate
        {
            get
            {
                return _JoiningDate;
            }
            set
            {
                _JoiningDate = value;
            }
        }

        protected SqlDateTime _CreationDate;
        public SqlDateTime  CreationDate
        {
            get
            {
                return _CreationDate;
            }
            set
            {
                _CreationDate = value;
            }
        }
    }
}