﻿using SortsClub.ENT;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for GameENT
/// </summary>
/// 
namespace SporttsClub.ENT
{
    public class GameENT:GameENTBase
    {
       
    }
}