﻿using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for GameTypeENTBase
/// </summary>
/// 
namespace SportsClub.ENT
{
    public abstract class GameTypeENTBase
    {
        protected SqlInt32 _GameTypeID;
        public SqlInt32 GameTypeID
        {
            get
            {
                return _GameTypeID;
            }
            set
            {
                _GameTypeID = value;
            }
        }

        protected SqlString _GameTypeName;
        public SqlString GameTypeName
        {
            get
            {
                return _GameTypeName;
            }
            set
            {
                _GameTypeName = value;
            }
        }

        protected SqlDateTime _CreationDate;
        public SqlDateTime CreationDate
        {
            get
            {
                return _CreationDate;
            }
            set
            {
                _CreationDate = value;
            }
        }
    }
}