﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for PlayerENT
/// </summary>
/// 
namespace SportsClub.ENT
{
    public class PlayerENT : PlayerENTBase
    {

    }
}