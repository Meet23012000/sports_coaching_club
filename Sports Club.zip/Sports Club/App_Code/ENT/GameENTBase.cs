﻿using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for GameENTBase
/// </summary>
/// 
namespace SortsClub.ENT
{
    public abstract class GameENTBase
    {
        protected SqlInt32 _GameID;
        public SqlInt32 GameID
        {
            get
            {
                return _GameID;
            }
            set
            {
                _GameID = value;
            }
        }

        protected SqlString _GameName;
        public SqlString GameName
        {
            get
            {
                return _GameName;
            }
            set
            {
                _GameName = value;
            }
        }

        protected SqlInt32 _GameTypeID;
        public SqlInt32 GameTypeID
        {
            get
            {
                return _GameTypeID;
            }
            set
            {
                _GameTypeID = value;
            }
        }

        protected SqlDateTime _GameStartingTime;
        public SqlDateTime GameStartingTime
        {
            get
            {
                return _GameStartingTime;
            }
            set
            {
                _GameStartingTime = value;
            }
        }

        protected SqlDateTime _GameEndingTime;
        public SqlDateTime GameEndingTime
        {
            get
            {
                return _GameEndingTime;
            }
            set
            {
                _GameEndingTime = value;
            }
        }

        protected SqlDateTime _CreationDate;
        public SqlDateTime CreationDate
        {
            get
            {
                return _CreationDate;
            }
            set
            {
                _CreationDate = value;
            }
        }

        protected SqlString _PhotoPath;
        public SqlString PhotoPath
        {
            get
            {
                return _PhotoPath;
            }
            set
            {
                _PhotoPath = value;
            }
        }
    }
}