﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for UserMasterENT
/// </summary>
/// 
namespace SportsClub
{
    public class UserMasterENT
    {
        public UserMasterENT()
        {
            //
            // TODO: Add constructor logic here
            //
        }
    }
}