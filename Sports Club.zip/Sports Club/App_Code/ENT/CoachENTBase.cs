﻿using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for CoachENTBase
/// </summary>
/// 
namespace SportsClub.ENT
{
    public abstract class CoachENTBase
    {
        protected SqlInt32 _CoachID;
        public SqlInt32 CoachID
        {
            get
            {
                return _CoachID;
            }
            set
            {
                _CoachID = value;
            }
        }

        protected SqlString _CoachName;
        public SqlString CoachName
        {
            get
            {
                return _CoachName;
            }
            set
            {
                _CoachName = value;
            }
        }


        protected SqlString _CoachFullName;
        public SqlString CoachFullName
        {
            get
            {
                return _CoachFullName;
            }
            set
            {
                _CoachFullName = value;
            }
        }

        protected SqlString _MobileNO;
        public SqlString MobileNO
        {
            get
            {
                return _MobileNO;
            }
            set
            {
                _MobileNO = value;
            }
        }

        protected SqlString _Address;
        public SqlString Address
        {
            get
            {
                return _Address;
            }
            set
            {
                _Address = value;
            }
        }

        protected SqlString _Email;
        public SqlString Email
        {
            get
            {
                return _Email;
            }
            set
            {
                _Email = value;
            }
        }

        protected SqlInt32 _GameID;
        public SqlInt32 GameID
        {
            get
            {
                return _GameID;
            }
            set
            {
                _GameID = value;
            }
        }

        protected SqlInt32 _Experience;
        public SqlInt32 Experience
        {
            get
            {
                return _Experience;
            }
            set
            {
                _Experience = value;
            }
        }

        protected SqlDateTime _CreationDate;
        public SqlDateTime CreationDate
        {
            get
            {
                return _CreationDate;
            }
            set
            {
                _CreationDate = value;
            }
        }

    }
}