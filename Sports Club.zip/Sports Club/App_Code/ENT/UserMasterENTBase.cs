﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for UserMasterENTBase
/// </summary>
public class UserMasterENTBase
{
	public UserMasterENTBase()
	{
		//
		// TODO: Add constructor logic here
		//
	}
}