﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for GameTypeENT
/// </summary>
/// 
namespace SportsClub.ENT
{
    public class GameTypeENT : GameTypeENTBase
    {
        
    }
}