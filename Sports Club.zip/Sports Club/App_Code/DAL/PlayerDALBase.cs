﻿using SportsClub.ENT;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for PlayerDALBase
/// </summary>
/// 
namespace SportsClub.DAL
{
    public abstract class PlayerDALBase : DatabaseConfig
    {

        #region Local Variable

        protected string _Message;

        public String Message
        {
            get
            {
                return _Message;
            }
            set
            {
                _Message = value;
            }
        }
        #endregion Local Variable

        #region Insert Oprations

        public Boolean Insert(PlayerENT entPlayer)
        {
            using (SqlConnection objConnection = new SqlConnection(DatabaseConfig.ConnectionString))
            {
                objConnection.Open();
                using (SqlCommand objcmd = objConnection.CreateCommand())
                {
                    try
                    {
                        #region Prepare Command
                        objcmd.CommandType = CommandType.StoredProcedure;
                        objcmd.CommandText = "PR_Player_Insert";
                        objcmd.Parameters.AddWithValue("@PlayerName", entPlayer.PlayerName);
                        objcmd.Parameters.AddWithValue("@PlayerFullName", entPlayer.PlayerFullName);
                        objcmd.Parameters.AddWithValue("@MobileNO", entPlayer.MobileNO);
                        objcmd.Parameters.AddWithValue("@Address", entPlayer.Address);
                        objcmd.Parameters.AddWithValue("@Email", entPlayer.Email);
                        objcmd.Parameters.AddWithValue("@CoachID", entPlayer.CoachID);
                        objcmd.Parameters.AddWithValue("@JoiningDate", entPlayer.JoiningDate);
                        
                        #endregion Prepare Command

                        #region ReadData And Set Control




                        objcmd.ExecuteNonQuery();
                      
                        return true;

                        #endregion ReadData And Set Control
                    }
                    catch (SqlException sqlex)
                    {
                        Message = sqlex.InnerException.Message.ToString();
                        return false;
                    }
                    catch (Exception ex)
                    {
                        Message = ex.InnerException.Message.ToString();
                        return false;
                    }
                    finally
                    {
                        if (objConnection.State == ConnectionState.Open)
                            objConnection.Close();
                    }
                }
            }
        }

        #endregion Insert Oprations

        #region Update Oprations

        public Boolean Update(PlayerENT entPlayer)
        {
            using (SqlConnection objConnection = new SqlConnection(DatabaseConfig.ConnectionString))
            {
                objConnection.Open();
                using (SqlCommand objcmd = objConnection.CreateCommand())
                {
                    try
                    {
                        #region Prepare Command
                        objcmd.CommandType = CommandType.StoredProcedure;
                        objcmd.CommandText = "PR_Player_UpdateByPK";
                        objcmd.Parameters.AddWithValue("@PlayerID", entPlayer.PlayerID);
                        objcmd.Parameters.AddWithValue("@PlayerName", entPlayer.PlayerName);
                        objcmd.Parameters.AddWithValue("@PlayerFullName", entPlayer.PlayerFullName);
                        objcmd.Parameters.AddWithValue("@MobileNO", entPlayer.MobileNO);
                        objcmd.Parameters.AddWithValue("@Address", entPlayer.Address);
                        objcmd.Parameters.AddWithValue("@Email", entPlayer.Email);
                        objcmd.Parameters.AddWithValue("@CoachID", entPlayer.CoachID);
                        objcmd.Parameters.AddWithValue("@JoiningDate", entPlayer.JoiningDate);

                        #endregion Prepare Command

                        #region ReadData And Set Control




                        objcmd.ExecuteNonQuery();

                        return true;

                        #endregion ReadData And Set Control
                    }
                    catch (SqlException sqlex)
                    {
                        Message = sqlex.InnerException.Message.ToString();
                        return false;
                    }
                    catch (Exception ex)
                    {
                        Message = ex.InnerException.Message.ToString();
                        return false;
                    }
                    finally
                    {
                        if (objConnection.State == ConnectionState.Open)
                            objConnection.Close();
                    }
                }
            }
        }

        #endregion Update Oprations

        #region Delete Oprations

        public Boolean Delete(SqlInt32 PlayerID)
        {
            using (SqlConnection objConnection = new SqlConnection(DatabaseConfig.ConnectionString))
            {
                objConnection.Open();
                using (SqlCommand objcmd = objConnection.CreateCommand())
                {
                    try
                    {
                        #region Prepare Command
                        objcmd.CommandType = CommandType.StoredProcedure;
                        objcmd.CommandText = "PR_Player_DeletePK";
                        objcmd.Parameters.AddWithValue("@PlayerID", PlayerID);
                        

                        #endregion Prepare Command

                        #region ReadData And Set Control




                        objcmd.ExecuteNonQuery();

                        return true;

                        #endregion ReadData And Set Control
                    }
                    catch (SqlException sqlex)
                    {
                        Message = sqlex.InnerException.Message.ToString();
                        return false;
                    }
                    catch (Exception ex)
                    {
                        Message = ex.InnerException.Message.ToString();
                        return false;
                    }
                    finally
                    {
                        if (objConnection.State == ConnectionState.Open)
                            objConnection.Close();
                    }
                }
            }
        }

        #endregion Delete Oprations

        #region Select Oprations

        public DataTable SelectAll()
        {
            using (SqlConnection objConnection = new SqlConnection(DatabaseConfig.ConnectionString))
            {
                objConnection.Open();
                using (SqlCommand objcmd = objConnection.CreateCommand())
                {
                    try
                    {
                        #region Prepare Command
                        objcmd.CommandType = CommandType.StoredProcedure;
                        objcmd.CommandText = "PR_Player_SelectAll";
                        // objcmd.Parameters.AddWithValue("@UserID", 1);
                        #endregion Prepare Command

                        #region ReadData And Set Control

                        DataTable dt = new DataTable();
                        using(SqlDataReader objSDR = objcmd.ExecuteReader())
                        {
                            dt.Load(objSDR);
                        }
                        return dt;
                        #endregion ReadData And Set Control
                    }
                    catch (SqlException sqlex)
                    {
                        Message = sqlex.InnerException.Message.ToString();
                        return null;
                    }
                    catch (Exception ex)
                    {
                        Message = ex.InnerException.Message.ToString();
                        return null;
                    }
                    finally
                    {
                        if (objConnection.State == ConnectionState.Open)
                            objConnection.Close();
                    }
                }
            }
        }

        public PlayerENT SelectByPK(SqlInt32 PlayerID)
        {
            using (SqlConnection objConnection = new SqlConnection(DatabaseConfig.ConnectionString))
            {
                objConnection.Open();
                using (SqlCommand objcmd = objConnection.CreateCommand())
                {
                    try
                    {
                        #region Prepare Command
                        objcmd.CommandType = CommandType.StoredProcedure;
                        objcmd.CommandText = "PR_Player_SelectPK";
                        objcmd.Parameters.AddWithValue("@PlayerID", PlayerID);
                        #endregion Prepare Command

                        #region ReadData And Set Control

                        PlayerENT entPlayer = new PlayerENT();

                        
                        using (SqlDataReader objSDR = objcmd.ExecuteReader())
                        {
                            while (objSDR.Read())
                            {
                                if (!objSDR["PlayerID"].Equals(DBNull.Value))
                                {
                                    entPlayer.PlayerID = Convert.ToInt32(objSDR["PlayerID"]);
                                }
                                if (!objSDR["PlayerName"].Equals(DBNull.Value))
                                {
                                    entPlayer.PlayerName = Convert.ToString(objSDR["PlayerName"]);
                                }
                                if (!objSDR["PlayerFullName"].Equals(DBNull.Value))
                                {
                                    entPlayer.PlayerFullName = Convert.ToString(objSDR["PlayerFullName"]);
                                }
                                if (!objSDR["MobileNO"].Equals(DBNull.Value))
                                {
                                    entPlayer.MobileNO = Convert.ToString(objSDR["MobileNO"]);
                                }
                                if (!objSDR["Address"].Equals(DBNull.Value))
                                {
                                    entPlayer.Address = Convert.ToString(objSDR["Address"]);
                                }
                                if (!objSDR["Email"].Equals(DBNull.Value))
                                {
                                    entPlayer.Email = Convert.ToString(objSDR["Email"]);
                                }
                                if (!objSDR["CoachID"].Equals(DBNull.Value))
                                {
                                    entPlayer.CoachID = Convert.ToInt32(objSDR["CoachID"]);
                                }
                                if (!objSDR["JoiningDate"].Equals(DBNull.Value))
                                {
                                    entPlayer.JoiningDate = Convert.ToDateTime(objSDR["JoiningDate"]);
                                }
                                if (!objSDR["CreationDate"].Equals(DBNull.Value))
                                {
                                    entPlayer.CreationDate = Convert.ToDateTime(objSDR["CreationDate"]);
                                }
                            }
                        }
                        return entPlayer;
                        
                        #endregion ReadData And Set Control
                    }
                    catch (SqlException sqlex)
                    {
                        Message = sqlex.InnerException.Message.ToString();
                        return null;
                    }
                    catch (Exception ex)
                    {
                        Message = ex.InnerException.Message.ToString();
                        return null;
                    }
                    finally
                    {
                        if (objConnection.State == ConnectionState.Open)
                            objConnection.Close();
                    }
                }
            }
        }

        public DataTable SelectDropDownList()
        {
            using (SqlConnection objConnection = new SqlConnection(DatabaseConfig.ConnectionString))
            {
                objConnection.Open();
                using (SqlCommand objcmd = objConnection.CreateCommand())
                {
                    try
                    {
                        #region Prepare Command
                        objcmd.CommandType = CommandType.StoredProcedure;
                        objcmd.CommandText = "PR_Player_SelectDropDownList";
                        // objcmd.Parameters.AddWithValue("@UserID", 1);
                        #endregion Prepare Command

                        #region ReadData And Set Control

                        DataTable dt = new DataTable();
                        using (SqlDataReader objSDR = objcmd.ExecuteReader())
                        {
                            dt.Load(objSDR);
                        }
                        return dt;
                        #endregion ReadData And Set Control
                    }
                    catch (SqlException sqlex)
                    {
                        Message = sqlex.InnerException.Message.ToString();
                        return null;
                    }
                    catch (Exception ex)
                    {
                        Message = ex.InnerException.Message.ToString();
                        return null;
                    }
                    finally
                    {
                        if (objConnection.State == ConnectionState.Open)
                            objConnection.Close();
                    }
                }
            }
        }
        
        #endregion Select Oprations

    }
}