﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Content_SportsClubMaster : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            if (Session["UserID"] == null)
            {
                Response.Redirect("~/WebSite/Pages/LoginPage.aspx");
            }
            if (Session["FullName"] != null)
            {
                lblUserName.Text = "Hi " + Session["FullName"].ToString();
            }
        }
    }
    protected void btnLogout_Click(object sender, EventArgs e)
    {
        Session.Clear();
        Response.Redirect("~/WebSite/Pages/LoginPage.aspx");
    }
}
