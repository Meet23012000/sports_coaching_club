﻿using SportsClub;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Pages_SignupPage : System.Web.UI.Page
{
    #region Page Load
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    #endregion Page Load

    #region Button SignUp
    protected void btnLogin_Click(object sender, EventArgs e)
    {
        using (SqlConnection objConnection = new SqlConnection(DatabaseConfig.ConnectionString))
        {

            objConnection.Open();
            using (SqlCommand objcmd = objConnection.CreateCommand())
            {



                try
                {
                    #region Prepare Command
                    objcmd.CommandType = CommandType.StoredProcedure;
                    objcmd.Parameters.AddWithValue("@UserName", txtUserName.Text.Trim());
                    objcmd.Parameters.AddWithValue("@Password", txtPassword.Text.Trim());
                    objcmd.Parameters.AddWithValue("@FullName", txtFullName.Text.Trim());
                    objcmd.Parameters.AddWithValue("@MobileNO", txtmobile.Text.Trim());
                    objcmd.Parameters.AddWithValue("@EmailID", txtEmail.Text.Trim());
                    objcmd.CommandText = "PR_UserMaster_Insert";
                    #endregion Prepare Command

                    objcmd.ExecuteNonQuery();
                    Response.Redirect("~/Pages/LoginPage.aspx");
                    lblmessage.Text = "SuccesFully Sign IN Go And Log IN";
                }
                catch
                {
                    lblError.Text = "User Already Exists...Please Enter Another username";
                }
                finally
                {
                    if (objConnection.State == ConnectionState.Open)
                        objConnection.Close();
                }
            }
        }
           

    }
    #endregion Button SignUp
}