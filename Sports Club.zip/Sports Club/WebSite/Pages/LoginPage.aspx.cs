﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Pages_LoginPage : System.Web.UI.Page
{

    #region Page_Load
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    #endregion Page_Load


    #region btnLogin
    protected void btnLogin_Click(object sender, EventArgs e)
    {
        #region Server Side Validation

        String strErrorMessage = "";
        if (txtUserName.Text.Trim() == "")
        {
            strErrorMessage += "  -  Enter UserName<br/>";
        }
        if (txtPassword.Text.Trim() == "")
        {
            strErrorMessage += "  -  Enter Password<br/>";
        }
        if (strErrorMessage != "")
        {
            lblmessage.Text = strErrorMessage;
            return;
        }

        #endregion Server Side Validation

        SqlConnection objConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["AddressBookConnectionString"].ConnectionString);
        objConnection.Open();
        //DataTable dt = new DataTable();
        SqlCommand objcmd = new SqlCommand();
        objcmd.Connection = objConnection;
        objcmd.CommandType = CommandType.StoredProcedure;
        //objcmd.Connection = objConnection;
        objcmd.CommandText = "PR_UserMaster_SelectByUserNamePassword";
        objcmd.Parameters.AddWithValue("@UserName", txtUserName.Text.Trim());
        objcmd.Parameters.AddWithValue("@Password", txtPassword.Text.Trim());
        SqlDataReader objSDR = objcmd.ExecuteReader();

        DataTable dtUser = new DataTable();
        dtUser.Load(objSDR);
        objConnection.Close();

        if (dtUser != null && dtUser.Rows.Count > 0)
        {
            foreach (DataRow drUser in dtUser.Rows)
            {
                if (!drUser["UserID"].Equals(DBNull.Value))
                {
                    Session["UserID"] = drUser["UserID"].ToString();
                }
                if (!drUser["FullName"].Equals(DBNull.Value))
                {
                    Session["FullName"] = drUser["FullName"].ToString();
                }
                break;
            }
            Response.Redirect("~/WebSite/Pages/Home.aspx");
        }
        else
        {
            lblmessage.Text = "Either Username or password is incorrect";
            txtUserName.Text = "";
            txtPassword.Text = "";
            txtUserName.Focus();
        }
        //SqlDataAdapter sda = new SqlDataAdapter();
        //sda.SelectCommand = objcmd;
        //sda.Fill(dt);
        //objConnection.Open();
        //objConnection.Close();

        //if (dt.Rows.Count > 0)
        //{
        //    Session["UserName"] = txtUserName.Text.ToString();
        //    Response.Redirect("~/MasterPanel/Contacts/ContactList.aspx");
        //}
        //else
        //{
        //   lblmessage.Text = "Invalid UserName or Password";
        //}
        //txtPassword.Text = "";
        //txtUserName.Text = "";
    }
    #endregion btnLogin
}