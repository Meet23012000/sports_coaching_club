﻿using SportsClub;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Pages_Home : System.Web.UI.Page
{
    #region Page_Load
    protected void Page_Load(object sender, EventArgs e)
    {
        
        if (Session["FullName"] != null)
        {
            lblUserName.Text = "Welcome " + Session["FullName"].ToString();
        }
        if (!Page.IsPostBack)
        {
            FillDropDownGameName();
            //if (Request.QueryString["GameID"] != null)
            //{

              //  loadControls(Convert.ToInt32(Request.QueryString["GameID"].ToString()));
            //}



        }

    }
    #endregion Page_Load

    #region FillPlayer

    private void FillPlayerGrid()
    {
        using (SqlConnection objConnection = new SqlConnection(DatabaseConfig.ConnectionString))
        {
            objConnection.Open();
            using (SqlCommand objcmd = objConnection.CreateCommand())
            {
                try
                {
                    #region Prepare Command
                    objcmd.CommandType = CommandType.StoredProcedure;
                    objcmd.CommandText = "PR_Player_SelectAll";
                    // objcmd.Parameters.AddWithValue("@UserID", 1);
                    #endregion Prepare Command
                    SqlDataReader objSDR = objcmd.ExecuteReader();
                    gvSearchGame.DataSource = objSDR;
                    gvSearchGame.DataBind();
                }
                catch (Exception ex)
                {
                    lblmessage.Text = ex.Message.ToString();
                }
                finally
                {
                    if (objConnection.State == ConnectionState.Open)
                        objConnection.Close();
                }
            }
        }
    }
    #endregion FillPlayer

    #region FillDropDown GameName
    private void FillDropDownGameName()
    {
        using (SqlConnection objConnection = new SqlConnection(DatabaseConfig.ConnectionString))
        {

            objConnection.Open();
            using (SqlCommand objcmd = objConnection.CreateCommand())
            {
                try
                {
                    #region Prepare   Command
                    objcmd.CommandType = CommandType.StoredProcedure;
                    objcmd.CommandText = "PR_Game_SelectDropDownList";
                    //objcmd.Parameters.AddWithValue("@UserID", 1);
                    #endregion Prepare   Command

                    #region Read Date
                    ddlsearchgame.Items.Insert(0, new ListItem("-----Select GameName-----"));
                    ddlsearchgame.Items[0].Attributes.Add("Disabled", "true");
                    ddlsearchgame.Items[0].Attributes.Add("Selected", "true");

                    SqlDataReader objSDRGameName = objcmd.ExecuteReader();
                    ddlsearchgame.DataSource = objSDRGameName;

                    ddlsearchgame.DataTextField = "GameName";
                    ddlsearchgame.DataValueField = "GameID";
                    ddlsearchgame.DataBind();
                    #endregion Read Date
                }
                catch (Exception ex)
                {
                    lblmessage.Text = ex.Message.ToString();
                }
                finally
                {
                    if (objConnection.State == ConnectionState.Open)
                        objConnection.Close();
                }
            }
        }
    }
    #endregion FillDropDown GameName

    #region btnsearch
    protected void btnsearch_Click(object sender, EventArgs e)
    {
        #region Local Variables
        
        SqlString strGameID = SqlString.Null;
        
        #endregion Local Variables

        #region Read Data
        if (ddlsearchgame.SelectedIndex != 0)
        {
            strGameID = ddlsearchgame.SelectedValue;
        }

        #endregion Read Data

        using (SqlConnection objConnection = new SqlConnection(DatabaseConfig.ConnectionString))
        {

            objConnection.Open();
            using (SqlCommand objcmd = objConnection.CreateCommand())
            {
                try
                {
                    #region Prepare Command
                    objcmd.Parameters.AddWithValue("@GameID", strGameID);
                    objcmd.Parameters.Add("@Playercount", SqlDbType.Int).Direction = ParameterDirection.Output;
                    objcmd.CommandType = CommandType.StoredProcedure;
                    objcmd.CommandText = "PR_Player_SelectAllSearchGame";

                   
                    #endregion Prepare Command

                    SqlDataReader objSDR = objcmd.ExecuteReader();

                    

                    #region Data Table
                    DataTable dtGame = new DataTable();
                    dtGame.Load(objSDR);
                    #endregion Data Table

                    Label1.Text = objcmd.Parameters["@Playercount"].Value.ToString();

                    gvSearchGame.DataSource = dtGame;
                    gvSearchGame.DataBind();


                }
                catch (Exception ex)
                {
                    lblmessage.Text = ex.Message.ToString();
                }
                finally
                {
                    

                   


                    if (objConnection.State == ConnectionState.Open)
                        objConnection.Close();
                }

            }
        }

        using (SqlConnection objConnection = new SqlConnection(DatabaseConfig.ConnectionString))
        {
            objConnection.Open();
            using (SqlCommand objcmd = objConnection.CreateCommand())
            {
                try
                {
                    #region Prepare Command
                    objcmd.CommandType = CommandType.StoredProcedure;
                    objcmd.Parameters.AddWithValue("@GameID", strGameID);
                    objcmd.CommandText = "PR_Game_SelectAllDisplayImage";
                    //objcmd.Parameters.AddWithValue("@UserID", 1);
                    #endregion Prepare Command


                    SqlDataReader objSDR = objcmd.ExecuteReader();



                    rptGame.DataSource = objSDR;
                    rptGame.DataBind();
                }
                catch (Exception ex)
                {
                    lblmessage.Text = ex.Message.ToString();
                }
                finally
                {
                    if (objConnection.State == ConnectionState.Open)
                        objConnection.Close();
                }
            }
        }
    }
    #endregion btnsearch
}