﻿using SportsClub;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Sports_Panel_Game_GameAddEdit : System.Web.UI.Page
{
    #region Page_load
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            FillDropDown();
            if (Request.QueryString["GameID"] != null)
            {

                loadControls(Convert.ToInt32(Request.QueryString["GameID"].ToString()));

            }



        }

    }
    #endregion Page_load

    #region loadControls
    private void loadControls(Int32 GameID)
    {
        using (SqlConnection objConnection = new SqlConnection(DatabaseConfig.ConnectionString))
        {

            objConnection.Open();
            using (SqlCommand objcmd = objConnection.CreateCommand())
            {
                try
                {

                    #region Prepare Command
                    objcmd.CommandType = CommandType.StoredProcedure;
                    objcmd.CommandText = "PR_Game_SelectPK";
                    objcmd.Parameters.AddWithValue("@GameID", GameID);
                    #endregion Prepare Command

                    #region ReadData and Set Controls
                    SqlDataReader objsdr = objcmd.ExecuteReader();

                    if (objsdr.HasRows == true)
                    {
                        while (objsdr.Read() == true)
                        {
                            if (!objsdr["GameName"].Equals(DBNull.Value))
                            {
                                txtGameName.Text = objsdr["GameName"].ToString();
                            }
                            if (!objsdr["GameTypeID"].Equals(DBNull.Value))
                            {
                                ddlGameType.SelectedValue = objsdr["GameTypeID"].ToString();

                            }
                            if (!objsdr["GameStartingTime"].Equals(DBNull.Value))
                            {
                                TxtGameStating.Text = objsdr["GameStartingTime"].ToString();
                            }
                            if (!objsdr["GameEndingTime"].Equals(DBNull.Value))
                            {
                                TxtGameEnding.Text = objsdr["GameEndingTime"].ToString();
                            }
                            if (!objsdr["PhotoPath"].Equals(DBNull.Value))
                            {
                                imgGame.ImageUrl = objsdr["PhotoPath"].ToString();
                                imgGame.Visible = true;
                                imgGame.Enabled = false;
                            }
                            else
                            {
                                imgGame.Visible = true;
                                lblMessageUpload.Text = objsdr["PhotoPath"].ToString();
                                imgGame.ImageUrl = objsdr["PhotoPath"].ToString();
                                lblmessage.Text = Server.MapPath(lblMessageUpload.Text);
                            }
                        }
                    }
                    #endregion ReadData and Set Controls
                }
                catch (Exception ex)
                {
                    lblmessage.Text = ex.Message.ToString();
                }
                finally
                {
                    if (objConnection.State == ConnectionState.Open)
                        objConnection.Close();
                }
            }
        }
    }
    #endregion loadControls


    #region FillDropDownGameType
    private void FillDropDown()
    {
        using (SqlConnection objConnection = new SqlConnection(DatabaseConfig.ConnectionString))
        {

            objConnection.Open();
            using (SqlCommand objcmd = objConnection.CreateCommand())
            {
                try
                {
                    #region Prepare Command
                    objcmd.CommandType = CommandType.StoredProcedure;
                    objcmd.CommandText = "PR_GameType_SelectDropDownList";
                    //objcmd.Parameters.AddWithValue("@UserID", 1);
                    #endregion Prepare Command

                    #region Read Data

                    ddlGameType.Items.Insert(0, new ListItem("<-----Select GameType----->"));
                    ddlGameType.Items[0].Attributes.Add("Disabled", "true");
                    ddlGameType.Items[0].Attributes.Add("Selected", "true");
                    // Execute
                    SqlDataReader objSDRGameType = objcmd.ExecuteReader();
                    ddlGameType.DataSource = objSDRGameType;

                    ddlGameType.DataTextField = "GameTypeName";
                    ddlGameType.DataValueField = "GameTypeID";
                    ddlGameType.DataBind();
                    #endregion Read Data
                }
                catch (Exception ex)
                {
                    lblmessage.Text = ex.Message.ToString();
                }
                finally
                {
                    if (objConnection.State == ConnectionState.Open)
                        objConnection.Close();
                }
            }
        }
    }
    #endregion FillDropDownGameType

    #region Button : Add
    protected void btnadd_ClickGameName(object sender, EventArgs e)
    {

        #region Local Variables
        SqlString strGameName = SqlString.Null;
        SqlString strGameTypeID = SqlString.Null;
        SqlString strGameStartingTime = SqlString.Null;
        SqlString strGameEndingTime = SqlString.Null;
        SqlString strGameImage = SqlString.Null;
        string strPhotoUrl = "~/WebSite/images/Game/";
        #endregion Local Variables

        #region Server Side Validation

        string strError = "";
        if (txtGameName.Text.Trim() == "")
            strError += " - Enter Game Name<br />";

        if (ddlGameType.SelectedIndex.Equals(0))
            strError += " - Enter Game Name<br />";




        if (strError.Trim() != "")
        {
            lblmessage.Text = strError;
            return;
        }

        #endregion Server Side Validation

        #region Read Data
        if (txtGameName.Text.Trim() != "")
            strGameName = txtGameName.Text.Trim();

        if (ddlGameType.SelectedIndex.Equals(0))

            strGameTypeID = ddlGameType.SelectedValue;

        if (TxtGameStating.Text.Trim() != "")
            strGameStartingTime = TxtGameStating.Text.Trim();

        if (TxtGameEnding.Text.Trim() != "")
            strGameEndingTime = TxtGameEnding.Text.Trim();


        if (fuimg.HasFile)
        {

            string strFilePath = "~/WebSite/images/Game" + fuimg.FileName;
            FileInfo file = new FileInfo(strFilePath);
            if (file.Exists)
            {
                file.Delete();
                lblMessageUpload.Text = "old file deleted successfully";
                lblMessageUpload.ForeColor = System.Drawing.Color.Red;
                strGameImage = strPhotoUrl + fuimg.FileName;
            }
            else
            {
                strGameImage = strPhotoUrl + fuimg.FileName;
            }

        }
        else
        {
            strGameImage = imgGame.ImageUrl;

        }


        #region Upload Image
        if (fuimg.HasFile)
        {
            string ImageExt = System.IO.Path.GetExtension(fuimg.FileName);



            if (ImageExt.ToLower() == ".jpeg" || ImageExt == ".jpg" || ImageExt == ".png" || ImageExt == ".jfif")
            {
            }
            else
            {
                lblMessageUpload.Text = "Only .jpeg files allowd!";
                lblMessageUpload.ForeColor = Color.Red;

                return;
            }
            HttpPostedFile file = fuimg.PostedFile;
            int iFileSize = file.ContentLength;
            if (iFileSize > 10048576) // 10 MB
            {
                lblMessageUpload.Text = "File Size Should be Less than 10 MB";
                lblMessageUpload.ForeColor = Color.Red;


                return;
            }


            if (!Directory.Exists(Server.MapPath(imgGame.ImageUrl)))
            {
                File.Delete(Server.MapPath(imgGame.ImageUrl));
            }
            fuimg.SaveAs(Server.MapPath(strPhotoUrl + fuimg.FileName));



        }
        else
        {
            lblMessageUpload.Text = "Kindly Select a Image to Upload";
            lblMessageUpload.ForeColor = Color.Red;


            //return;
        }

        #endregion Upload Image

        #endregion Read Data






        using (SqlConnection objConnection = new SqlConnection(DatabaseConfig.ConnectionString))
        {
            objConnection.Open();
            using (SqlCommand objcmd = objConnection.CreateCommand())
            {
                try
                {
                    #region Prepare Command
                    objcmd.CommandType = CommandType.StoredProcedure;

                    if (Request.QueryString["GameID"] == null)
                    {
                        objcmd.Parameters.AddWithValue("@GameName", txtGameName.Text.Trim());
                        objcmd.Parameters.AddWithValue("@GameTypeID", ddlGameType.SelectedValue);
                        objcmd.Parameters.AddWithValue("@GameStartingTime", DateTime.Now);
                        objcmd.Parameters.AddWithValue("@GameEndingTime", DateTime.Now);
                        objcmd.Parameters.AddWithValue("@PhotoPath", strGameImage);
                        objcmd.CommandText = "PR_Game_Insert";
                        //objcmd.Parameters.AddWithValue("@UserID", 1);
                        lblmessage.Text = "Data Added SucessuFully";
                    }
                    else
                    {
                        objcmd.CommandText = "PR_Game_UpdateByPK";
                        objcmd.Parameters.AddWithValue("@GameID", Request.QueryString["GameID"].ToString());
                        objcmd.Parameters.AddWithValue("@GameName", txtGameName.Text.Trim());
                        objcmd.Parameters.AddWithValue("@GameTypeID", ddlGameType.SelectedValue);
                        objcmd.Parameters.AddWithValue("@GameStartingTime", DateTime.Now);
                        objcmd.Parameters.AddWithValue("@GameEndingTime", DateTime.Now);
                        objcmd.Parameters.AddWithValue("@PhotoPath", strGameImage);

                        //objcmd.Parameters.AddWithValue("@UserID", 1);
                        lblmessage.Text = "Data Updated SucessFully";

                    }
                    #endregion Prepare Command
                    objcmd.ExecuteNonQuery();



                }
                catch (Exception ex)
                {
                    lblmessage.Text = ex.Message.ToString();
                }
                finally
                {
                    if (Request.QueryString["GameID"] == null)
                    {
                        txtGameName.Text = "";
                        TxtGameStating.Text = "";
                        TxtGameEnding.Text = "";
                        txtGameName.Focus();
                    }


                    if (objConnection.State == ConnectionState.Open)
                        objConnection.Close();
                }
            }
        }


        // Response.Redirect("~/GameType/List");
    }
    #endregion Button : Add

    #region Button : Cancle
    protected void btncancle_ClickGameName(object sender, EventArgs e)
    {
        txtGameName.Text = "";
        TxtGameStating.Text = "";
        TxtGameEnding.Text = "";
        txtGameName.Focus();
        lblmessage.Text = "";
        //Response.Redirect("");
    }
    #endregion Button : Cancle

    #region Button : Upload
    protected void btnUpload_Click(object sender, EventArgs e)
    {
        if (fuimg.HasFile)
        {
            string strFilePath = "~/WebSite/images/Game";
            //http://localhost:27532/WebSite/SportsPanel/images/Game
            //F:\Sports Club\WebSite\images\Game\
            fuimg.SaveAs(strFilePath + fuimg.FileName);
            lblMessageUpload.Text = Server.MapPath(strFilePath + fuimg.FileName);
        }
        else
        {
            lblMessageUpload.Text = "Select aFile to Upload";
        }
    }
    #endregion Button : Upload
}