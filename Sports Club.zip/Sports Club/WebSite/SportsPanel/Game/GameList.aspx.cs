﻿using SportsClub;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Sports_Panel_Game_GameList : System.Web.UI.Page
{
    #region Page_Load
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {

           // FillGameGrid();
            FillGame();

        }
    }
    #endregion Page_Load

    

   // #region RowCommand
    //protected void gvGame_RowCommand(object sender, GridViewCommandEventArgs e)
    //{
     //   if (e.CommandName == "DeleteRecord")
       // {
         //   #region Delete Record
           // Deleterecord(Convert.ToInt32(e.CommandArgument));
            //FillGame();
            //#endregion Delete Record
        //}
    //}
    //#endregion RowCommand

    #region DeleteRecord
    private void Deleterecord(Int32 GameID,string PhotoPath)
    {
        using (SqlConnection objConnection = new SqlConnection(DatabaseConfig.ConnectionString))
        {
            objConnection.Open();
            using (SqlCommand objcmd = objConnection.CreateCommand())
            {
                try
                {
                    #region Prepare Command
                    objcmd.CommandType = CommandType.StoredProcedure;
                    objcmd.Parameters.AddWithValue("@GameID", GameID);
                    objcmd.CommandText = "PR_Game_DeletePK";
                    #endregion Prepare Command
                    objcmd.ExecuteNonQuery();
                }
                catch
                {
                    lblError.Text = "This Game can't be deleted because this Game has a coach";
                }
                finally
                {
                    if (objConnection.State == ConnectionState.Open)
                        objConnection.Close();
                }
            }
        }

    }
    #endregion DeleteRecord


    #region FillGame
    private void FillGame()
    {
        using (SqlConnection objConnection = new SqlConnection(DatabaseConfig.ConnectionString))
        {
            objConnection.Open();
            using (SqlCommand objcmd = objConnection.CreateCommand())
            {
                try
                {
                    #region Prepare Command
                    objcmd.CommandType = CommandType.StoredProcedure;
                    objcmd.CommandText = "PR_Game_SelectAll";
                    //objcmd.Parameters.AddWithValue("@UserID", 1);
                    #endregion Prepare Command


                    SqlDataReader objSDR = objcmd.ExecuteReader();

                   

                    rptGame.DataSource = objSDR;
                    rptGame.DataBind();
                }
                catch (Exception ex)
                {
                    lblMessage.Text = ex.Message.ToString();
                }
                finally
                {
                    if (objConnection.State == ConnectionState.Open)
                        objConnection.Close();
                }
            }
        }
    }
    #endregion FillGame

    #region DeleteGame
    protected void rptGame_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        if (e.CommandName == "DeleteRecord")
        {
            #region Delete Record
            Deleterecord(Convert.ToInt32(e.CommandArgument),Convert.ToString(e.CommandArgument));
            FillGame();
            #endregion Delete Record
        }
    }
    #endregion DeleteGame
}