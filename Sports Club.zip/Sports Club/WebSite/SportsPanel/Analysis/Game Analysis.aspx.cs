﻿using SportsClub;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class SportsPanel_Analysis_Game_Analysis : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {

            FillGameAnalysisGrid();

        }
    }


    #region FillGameAnalysis

    private void FillGameAnalysisGrid()
    {
        using (SqlConnection objConnection = new SqlConnection(DatabaseConfig.ConnectionString))
        {
            objConnection.Open();
            using (SqlCommand objcmd = objConnection.CreateCommand())
            {
                try
                {
                    #region Prepare Command
                    objcmd.Parameters.Add("@Playercount", SqlDbType.Int).Direction = ParameterDirection.Output;
                    objcmd.CommandType = CommandType.StoredProcedure;
                    objcmd.CommandText = "PR_Player_SelectAllPCount";
                    //objcmd.Parameters.AddWithValue("@UserID", 1);
                    #endregion Prepare Command

                    SqlDataReader objSDR = objcmd.ExecuteReader();

                    #region DataTable
                    DataTable dtCount = new DataTable();
                    dtCount.Load(objSDR);
                    object sum;
                    sum = dtCount.Compute("sum(PlyerCount)", string.Empty);
                    Label2.Text = sum.ToString();
                    #endregion DataTable

                    
                    gvGame.DataSource = dtCount;
                    gvGame.DataBind();

                    


                }
                catch (Exception ex)
                {
                    lblMessage.Text = ex.Message.ToString();
                }
                finally
                {
                    if (objConnection.State == ConnectionState.Open)
                        objConnection.Close();
                }
            }
        }
    }
    #endregion FillGameAnalysis

    public string MyDataTable { get; set; }
}