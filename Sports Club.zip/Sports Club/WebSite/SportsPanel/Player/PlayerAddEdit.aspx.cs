﻿using SportsClub;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Sports_Panel_Player_PlayerAddEdit : System.Web.UI.Page
{
    #region Page_load
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {

            FillDropDownCoach();
           
            if (Request.QueryString["PlayerID"] != null)
            {
                
                loadControls(Convert.ToInt32(Request.QueryString["PlayerID"].ToString()));
            }
                        
            
        }

    }
    #endregion Page_load

    #region loadControls
    private void loadControls(Int32 PlayerID)
    {
        using (SqlConnection objConnection = new SqlConnection(DatabaseConfig.ConnectionString))
        {

            objConnection.Open();
            using (SqlCommand objcmd = objConnection.CreateCommand())
            {
                try
                {
                    #region Prepare Command
                    objcmd.CommandType = CommandType.StoredProcedure;
                    objcmd.CommandText = "PR_Player_SelectPK";
                     objcmd.Parameters.AddWithValue("@PlayerID", PlayerID);
                    #endregion Prepare Command

                    #region ReadData and Set Controls
                    SqlDataReader objsdr = objcmd.ExecuteReader();

                    if (objsdr.HasRows == true)
                    {
                        while (objsdr.Read() == true)
                        {
                            if (!objsdr["PlayerName"].Equals(DBNull.Value))
                            {
                                txtPlayerName.Text = objsdr["PlayerName"].ToString();
                            }
                            if (!objsdr["PlayerFullName"].Equals(DBNull.Value))
                            {
                                txtPlayerFullName.Text = objsdr["PlayerFullName"].ToString();
                            }
                            if (!objsdr["MobileNO"].Equals(DBNull.Value))
                            {
                                TxtMobileNO.Text = objsdr["MobileNO"].ToString();
                            }
                            if (!objsdr["Email"].Equals(DBNull.Value))
                            {
                                TxtEmail.Text = objsdr["Email"].ToString();
                            }
                            if (!objsdr["Address"].Equals(DBNull.Value))
                            {
                                txtAddress.Text = objsdr["Address"].ToString();
                            }
                            if (!objsdr["CoachID"].Equals(DBNull.Value))
                            {
                                
                                ddlCoach.SelectedValue = objsdr["CoachID"].ToString();

                            }
                            if (!objsdr["JoiningDate"].Equals(DBNull.Value))
                            {
                                txtJoining.Text = objsdr["JoiningDate"].ToString();
                            }


                        }
                    }
            #endregion ReadData and Set Controls
                 }
                 catch (Exception ex)
                {
                    lblmessage.Text = ex.Message.ToString();
                }
                finally
                {
                    if (objConnection.State == ConnectionState.Open)
                        objConnection.Close();
                }
            }
        }
    }
    #endregion loadControls


    


    

    #region FillDropDown Coach
    private void FillDropDownCoach()
    {
        using (SqlConnection objConnection = new SqlConnection(DatabaseConfig.ConnectionString))
        {

            objConnection.Open();
            using (SqlCommand objcmd = objConnection.CreateCommand())
            {
                try
                {
                    #region Prepare Command
                    objcmd.CommandType = CommandType.StoredProcedure;
                    objcmd.CommandText = "PR_Coach_SelectDropDownList";

                    //objcmd.Parameters.AddWithValue("@UserID", 1);
                    #endregion Prepare Command

                    #region Read Date
                    ddlCoach.Items.Insert(0, new ListItem("-----Select GameName-----"));
                    ddlCoach.Items[0].Attributes.Add("Disabled", "true");
                    ddlCoach.Items[0].Attributes.Add("Selected", "true");
                    // Execute
                    SqlDataReader objSDRCoachName = objcmd.ExecuteReader();
                    ddlCoach.DataSource = objSDRCoachName;

                    ddlCoach.DataTextField = "CoachName";
                    ddlCoach.DataValueField = "CoachID";
                    ddlCoach.DataBind();
                    #endregion Read Date
                }
                catch (Exception ex)
                {
                    lblmessage.Text = ex.Message.ToString();
                }
                finally
                {
                    if (objConnection.State == ConnectionState.Open)
                        objConnection.Close();
                }
            }
        }
    }
    #endregion FillDropDown Coach


    
    #region Button : Cancle
    protected void btnCancle_ClickPlayer(object sender, EventArgs e)
    {
        txtPlayerName.Text = "";
        txtPlayerFullName.Text = "";
        TxtMobileNO.Text = "";
        TxtEmail.Text = "";
        txtAddress.Text = "";




        txtJoining.Text = "";

        txtPlayerName.Focus();
        lblmessage.Text = "";
        //Response.Redirect("");
    }
    #endregion Button : Cancle

    #region btn Add
    protected void btnadd_ClickPlayer(object sender, EventArgs e)
    {
        #region Local Variables
        SqlString strPlayerName = SqlString.Null;
        SqlString strPlayerFullName = SqlString.Null;
        SqlString strMobileNO = SqlString.Null;
        SqlString strAddress = SqlString.Null;
        SqlString strEmail = SqlString.Null;
        SqlString strCoachID = SqlString.Null;
        SqlString strJoiningDate = SqlString.Null;
        #endregion Local Variables

        #region Server Side Validation

        string strError = "";
        if (txtPlayerName.Text.Trim() == "")
            strError += " - Enter Player Name<br />";

        if (txtPlayerFullName.Text.Trim() == "")
            strError += " - Enter Player Full Name<br />";

        if (TxtMobileNO.Text.Trim() == "")
            strError += " - Enter Mobile No<br />";

        if (txtAddress.Text.Trim() == "")
            strError += " - Enter Address<br />";

        if (TxtEmail.Text.Trim() == "")
            strError += " - Enter Email<br />";

        
        if (ddlCoach.SelectedIndex.Equals(0))
            strError += " - Enter Coach Name<br />";




        if (strError.Trim() != "")
        {
            lblmessage.Text = strError;
            return;
        }

        #endregion Server Side Validation

        #region Read Data
        if (txtPlayerName.Text.Trim() != "")
            strPlayerName = txtPlayerName.Text.Trim();

        if (txtPlayerFullName.Text.Trim() != "")
            strPlayerFullName = txtPlayerFullName.Text.Trim();

        if (TxtMobileNO.Text.Trim() != "")
            strMobileNO = TxtMobileNO.Text.Trim();

        if (txtAddress.Text.Trim() != "")
            strAddress = txtAddress.Text.Trim();

        if (TxtEmail.Text.Trim() != "")
            strEmail = TxtEmail.Text.Trim();

        if (ddlCoach.SelectedIndex.Equals(0))
            strCoachID = ddlCoach.SelectedValue;

        if (txtJoining.Text.Trim() != "")
            strJoiningDate = txtJoining.Text.Trim();






        #endregion Read Data



        using (SqlConnection objConnection = new SqlConnection(DatabaseConfig.ConnectionString))
        {

            objConnection.Open();
            using (SqlCommand objcmd = objConnection.CreateCommand())
            {
                try
                {
                    #region Prepare Command
                    objcmd.CommandType = CommandType.StoredProcedure;

                    if (Request.QueryString["PlayerID"] == null)
                    {
                        objcmd.Parameters.AddWithValue("@PlayerName", txtPlayerName.Text.Trim());
                        objcmd.Parameters.AddWithValue("@PlayerFullName", txtPlayerFullName.Text.Trim());
                        objcmd.Parameters.AddWithValue("@MobileNO", TxtMobileNO.Text.Trim());
                        objcmd.Parameters.AddWithValue("@Email", TxtEmail.Text.Trim());
                        objcmd.Parameters.AddWithValue("@Address", txtAddress.Text.Trim());
                        // objcmd.Parameters.AddWithValue("@GameTypeID", ddlGameType.SelectedValue);
                        //objcmd.Parameters.AddWithValue("@GameID", ddlGameName.SelectedValue);
                        objcmd.Parameters.AddWithValue("@CoachID", ddlCoach.SelectedValue);

                        objcmd.Parameters.AddWithValue("@JoiningDate", txtJoining.Text.Trim());
                        objcmd.CommandText = "PR_Player_Insert";
                        //objcmd.Parameters.AddWithValue("@UserID", 1);
                        lblmessage.Text = "Data Added SucessuFully";
                    }
                    else
                    {
                        objcmd.CommandText = "PR_Player_UpdateByPK";
                        objcmd.Parameters.AddWithValue("@PlayerID", Request.QueryString["PlayerID"].ToString());

                        objcmd.Parameters.AddWithValue("@PlayerName", txtPlayerName.Text.Trim());
                        objcmd.Parameters.AddWithValue("@PlayerFullName", txtPlayerFullName.Text.Trim());
                        objcmd.Parameters.AddWithValue("@MobileNO", TxtMobileNO.Text.Trim());
                        objcmd.Parameters.AddWithValue("@Email", TxtEmail.Text.Trim());
                        objcmd.Parameters.AddWithValue("@Address", txtAddress.Text.Trim());
                        // objcmd.Parameters.AddWithValue("@GameTypeID", ddlGameType.SelectedValue);
                        //objcmd.Parameters.AddWithValue("@GameID", ddlGameName.SelectedValue);
                        objcmd.Parameters.AddWithValue("@CoachID", ddlCoach.SelectedValue);

                        objcmd.Parameters.AddWithValue("@JoiningDate", txtJoining.Text.Trim());
                        //objcmd.Parameters.AddWithValue("@UserID", 1);
                        lblmessage.Text = "Data Updated SucessFully";
                    }
                    #endregion Prepare Command

                    objcmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    lblmessage.Text = ex.Message.ToString();
                }
                finally
                {
                    if (Request.QueryString["GameID"] == null)
                    {
                        txtPlayerName.Text = "";
                        txtPlayerFullName.Text = "";
                        TxtMobileNO.Text = "";
                        TxtEmail.Text = "";
                        txtAddress.Text = "";




                        txtJoining.Text = "";

                        txtPlayerName.Focus();

                    }


                    if (objConnection.State == ConnectionState.Open)
                        objConnection.Close();
                }

            }
        }
        

    }
    #endregion btn Add

    


    

}