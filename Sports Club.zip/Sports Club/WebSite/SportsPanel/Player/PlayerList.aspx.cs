﻿using SportsClub;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Sports_Panel_Player_PlayerList : System.Web.UI.Page
{
    #region Page_Load
    protected void Page_Load(object sender, EventArgs e)
    {
       
        
        if (!Page.IsPostBack)
        {
            FillDropDownGameName();
            FillDropDownCoach();
           // FillDropDownPlayer();
            FillPlayerGrid();

        }
    }
    #endregion Page_Load

    #region FillPlayer

    private void FillPlayerGrid()
    {
        using (SqlConnection objConnection = new SqlConnection(DatabaseConfig.ConnectionString))
        {
            objConnection.Open();
            using (SqlCommand objcmd = objConnection.CreateCommand())
            {
                try
                {
                    #region Prepare Command
                    objcmd.CommandType = CommandType.StoredProcedure;
                    objcmd.CommandText = "PR_Player_SelectAll";
                   // objcmd.Parameters.AddWithValue("@UserID", 1);
                    #endregion Prepare Command
                    SqlDataReader objSDR = objcmd.ExecuteReader();
                    gvPlayer.DataSource = objSDR;
                    gvPlayer.DataBind();
                }
                catch (Exception ex)
                {
                    lblMessage.Text = ex.Message.ToString();
                }
                finally
                {
                    if (objConnection.State == ConnectionState.Open)
                        objConnection.Close();
                }
            }
        }
    }
    #endregion FillPlayer

    #region RowCommand
    protected void gvPlayer_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "DeleteRecord")
        {
            #region Delete Record
            Deleterecord(Convert.ToInt32(e.CommandArgument));
            FillPlayerGrid();
            #endregion Delete Record
        }
    }
    #endregion RowCommand

    #region DeleteRecord
    private void Deleterecord(Int32 PlayerID)
    {
        using (SqlConnection objConnection = new SqlConnection(DatabaseConfig.ConnectionString))
        {
            objConnection.Open();
            using (SqlCommand objcmd = objConnection.CreateCommand())
            {
                try
                {
                    #region Prepare Command
                    objcmd.CommandType = CommandType.StoredProcedure;
                    objcmd.Parameters.AddWithValue("@PlayerID", PlayerID);
                    objcmd.CommandText = "PR_Player_DeletePK";
                    #endregion Prepare Command
                    objcmd.ExecuteNonQuery();
                }
                catch
                {
                    lblError.Text = "This Game can't be deleted because this country has a coach";
                }
                finally
                {
                    if (objConnection.State == ConnectionState.Open)
                        objConnection.Close();
                }
            }
        }

    }
    #endregion DeleteRecord

    #region FillDropDown GameName
    private void FillDropDownGameName()
    {
        using (SqlConnection objConnection = new SqlConnection(DatabaseConfig.ConnectionString))
        {

            objConnection.Open();
            using (SqlCommand objcmd = objConnection.CreateCommand())
            {
                try
                {
                    #region Prepare   Command
                    objcmd.CommandType = CommandType.StoredProcedure;
                    objcmd.CommandText = "PR_Game_SelectDropDownList";
                    //objcmd.Parameters.AddWithValue("@UserID", 1);
                    #endregion Prepare   Command

                    #region Read Date
                    ddlFilterGame.Items.Insert(0, new ListItem("-----Select GameName-----"));
                    ddlFilterGame.Items[0].Attributes.Add("Disabled", "true");
                    ddlFilterGame.Items[0].Attributes.Add("Selected", "true");

                    SqlDataReader objSDRGameName = objcmd.ExecuteReader();
                    ddlFilterGame.DataSource = objSDRGameName;

                    ddlFilterGame.DataTextField = "GameName";
                    ddlFilterGame.DataValueField = "GameID";
                    ddlFilterGame.DataBind();
                    #endregion Read Date
                }
                catch (Exception ex)
                {
                    lblMessage.Text = ex.Message.ToString();
                }
                finally
                {
                    if (objConnection.State == ConnectionState.Open)
                        objConnection.Close();
                }
            }
        }
    }
    #endregion FillDropDown GameName

    #region FillDropDown Coach
    private void FillDropDownCoach()
    {
        using (SqlConnection objConnection = new SqlConnection(DatabaseConfig.ConnectionString))
        {

            objConnection.Open();
            using (SqlCommand objcmd = objConnection.CreateCommand())
            {
                try
                {
                    #region Prepare Command
                    objcmd.CommandType = CommandType.StoredProcedure;
                    objcmd.CommandText = "PR_Coach_SelectDropDownList";

                    //objcmd.Parameters.AddWithValue("@UserID", 1);
                    #endregion Prepare Command

                    #region Read Date
                    ddlFlterCoach.Items.Insert(0, new ListItem("-----Select GameName-----"));
                    ddlFlterCoach.Items[0].Attributes.Add("Disabled", "true");
                    ddlFlterCoach.Items[0].Attributes.Add("Selected", "true");
                    // Execute
                    SqlDataReader objSDRCoachName = objcmd.ExecuteReader();
                    ddlFlterCoach.DataSource = objSDRCoachName;

                    ddlFlterCoach.DataTextField = "CoachName";
                    ddlFlterCoach.DataValueField = "CoachID";
                    ddlFlterCoach.DataBind();
                    #endregion Read Date
                }
                catch (Exception ex)
                {
                    lblMessage.Text = ex.Message.ToString();
                }
                finally
                {
                    if (objConnection.State == ConnectionState.Open)
                        objConnection.Close();
                }
            }
        }
    }
    #endregion FillDropDown Coach

    


    #region btnSearch

    protected void BtnSearch_Click(object sender, EventArgs e)
    {
        
        #region Local Variables
        
        SqlString strGameID = SqlString.Null;
        SqlString strCoachID = SqlString.Null;
        SqlString strPlayerName = SqlString.Null;
        
        #endregion Local Variables

        #region Read Data
        if (ddlFilterGame.SelectedIndex > 0)
        {
            strGameID = ddlFilterGame.SelectedValue;
        }
        if (ddlFlterCoach.SelectedIndex > 0)
        {
            strCoachID = ddlFlterCoach.SelectedValue;
        }
        if (txtPlayerName.Text.Trim() != "")
            strPlayerName = txtPlayerName.Text.Trim();

        #endregion Read Data

        using (SqlConnection objConnection = new SqlConnection(DatabaseConfig.ConnectionString))
        {

            objConnection.Open();
            using (SqlCommand objcmd = objConnection.CreateCommand())
            {
                try
                {
                    #region Prepare Command
                    objcmd.Parameters.AddWithValue("@GameID", strGameID);
                    objcmd.Parameters.AddWithValue("@CoachID", strCoachID);
                    objcmd.Parameters.AddWithValue("@PlayerName", strPlayerName);
                    objcmd.Parameters.Add("@Playercount", SqlDbType.Int).Direction = ParameterDirection.Output;
                    objcmd.CommandType = CommandType.StoredProcedure;
                    objcmd.CommandText = "PR_Player_SelectAllSearchFilter";

                   
                    #endregion Prepare Command

                    SqlDataReader objSDR = objcmd.ExecuteReader();

                    

                    #region Data Table
                    DataTable dtGame = new DataTable();
                    dtGame.Load(objSDR);
                    #endregion Data Table

                    Label1.Text = objcmd.Parameters["@Playercount"].Value.ToString();

                    gvPlayer.DataSource = dtGame;
                    gvPlayer.DataBind();


                }
                catch (Exception ex)
                {
                    lblMessage.Text = ex.Message.ToString();
                }
                finally
                {
                    

                   


                    if (objConnection.State == ConnectionState.Open)
                        objConnection.Close();
                }

            }
        }

        
    }
    #endregion btnSearch
}