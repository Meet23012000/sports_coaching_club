﻿using SportsClub;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Sports_Panel_GameType_GameTypeList : System.Web.UI.Page
{
    #region Page_load
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {

            FillGameTypeGrid();
        }
    }
    #endregion Page_load

    #region FillGameType

    private void FillGameTypeGrid()
    {
        using (SqlConnection objConnection = new SqlConnection(DatabaseConfig.ConnectionString))
        {
            objConnection.Open();
            using (SqlCommand objcmd = objConnection.CreateCommand())
            {
                try
                {
                    #region Prepare Command
                    objcmd.CommandType = CommandType.StoredProcedure;
                    objcmd.CommandText = "PR_GameType_SelectAll";
                    //objcmd.Parameters.AddWithValue("@UserID", 1);
                    #endregion Prepare Command

                    SqlDataReader objSDR = objcmd.ExecuteReader();
                    
                    

                    
                    gvGameType.DataSource = objSDR;
                    gvGameType.DataBind();
                }
                catch (Exception ex)
                {
                    lblMessage.Text = ex.Message.ToString();
                }
                finally
                {
                    if (objConnection.State == ConnectionState.Open)
                        objConnection.Close();
                }
                
            }
        }
    }
    #endregion FillGameType

    #region RowCommand
    protected void gvGameType_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        #region Delete Record
        if (e.CommandName == "DeleteRecord")
        {
            Deleterecord(Convert.ToInt32(e.CommandArgument));
            FillGameTypeGrid();
        }
        #endregion Delete Record
    }
    #endregion RowCommand

    #region DeleteRecord
    private void Deleterecord(Int32 GameTypeID)
    {
        using (SqlConnection objConnection = new SqlConnection(DatabaseConfig.ConnectionString))
        {
            objConnection.Open();
            using (SqlCommand objcmd = objConnection.CreateCommand())
            {
                try
                {
                    #region Prepare Command
                    objcmd.CommandType = CommandType.StoredProcedure;
                    objcmd.Parameters.AddWithValue("@GameTypeID", GameTypeID);
                    objcmd.CommandText = "PR_GameType_DeletePK";
                    #endregion Prepare Command
                    objcmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    lblError.Text = "This GameType can't be deleted because this GameType has a Game";
                    lblMessage.Text = ex.Message;

                }
                finally
                {
                    if (objConnection.State == ConnectionState.Open)
                        objConnection.Close();
                }
            }
        }

    }
    #endregion DeleteRecord

}