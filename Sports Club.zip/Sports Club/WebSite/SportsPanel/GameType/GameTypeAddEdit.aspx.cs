﻿using SportsClub;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Sports_Panel_GameType_GameTypeAddEdit : System.Web.UI.Page
{
    #region Page_load
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            if (Request.QueryString["GameTypeID"] != null)
            {
                #region Load data Edit mode
                loadControls(Convert.ToInt32(Request.QueryString["GameTypeID"].ToString()));
                #endregion Load data Edit mode
            }
            else
            {
                
            }

        }

    }
    #endregion Page_load

    #region loadControls
    private void loadControls(Int32 GameTypeID)
    {
        using (SqlConnection objConnection = new SqlConnection(DatabaseConfig.ConnectionString))
        {

            objConnection.Open();
            using (SqlCommand objcmd = objConnection.CreateCommand())
            {
                try
                {

                    #region Prepare Command
                    objcmd.CommandType = CommandType.StoredProcedure;
                    objcmd.CommandText = "PR_GameType_SelectPK";
                    objcmd.Parameters.AddWithValue("@GameTypeID", GameTypeID);
                    #endregion Prepare Command


                    #region ReadData and Set Controls
                    SqlDataReader objsdr = objcmd.ExecuteReader();

                    if (objsdr.HasRows == true)
                    {
                        while (objsdr.Read() == true)
                        {
                            if (!objsdr["GameTypeName"].Equals(DBNull.Value))
                            {
                                txtGameType.Text = objsdr["GameTypeName"].ToString();
                            }

                        }
                    }
                    #endregion ReadData and Set Controls

                }
                catch (Exception ex)
                {
                    lblmessage.Text = ex.Message.ToString();
                }
                finally
                {
                    if (objConnection.State == ConnectionState.Open)
                        objConnection.Close();
                }

            }
        }
    }
    #endregion loadControls

    #region Button : Add
    protected void btnadd_ClickGameType(object sender, EventArgs e)
    {

        #region Local Variables
        SqlString strGameTypeName = SqlString.Null;
        #endregion Local Variables

        #region Server Side Validation

        string strError = "";
        if (txtGameType.Text.Trim() == "")
            strError += " - Enter Country Name<br />";

        

        if (strError.Trim() != "")
        {
            lblmessage.Text = strError;
            return;
        }

        #endregion Server Side Validation

        #region Read Data
        if (txtGameType.Text.Trim() != "")
            strGameTypeName = txtGameType.Text.Trim();

        
        #endregion Read Data
        using (SqlConnection objConnection = new SqlConnection(DatabaseConfig.ConnectionString))
        {

            objConnection.Open();
            using (SqlCommand objcmd = objConnection.CreateCommand())
            {



                try
                {
                    #region Prepare Command
                    objcmd.CommandType = CommandType.StoredProcedure;
                    if (Request.QueryString["GameTypeID"] == null)
                    {
                        objcmd.Parameters.AddWithValue("@GameTypeName", txtGameType.Text.Trim());
                        objcmd.CommandText = "PR_GameType_Insert";
                        //objcmd.Parameters.AddWithValue("@UserID", 1);
                        lblmessage.Text = "Data Added SucessuFully";
                    }
                    else
                    {
                        objcmd.CommandText = "PR_GameType_UpdatebyPK";
                        objcmd.Parameters.AddWithValue("@GameTypeID", Request.QueryString["GameTypeID"].ToString());
                        objcmd.Parameters.AddWithValue("@GameTypeName", txtGameType.Text.Trim());
                        //objcmd.Parameters.AddWithValue("@UserID", 1);
                        lblmessage.Text = "Data Updated SucessFully";
                    }
                    #endregion Prepare Command
                    objcmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    lblmessage.Text = ex.Message.ToString();
                }
                finally
                {
                    if (Request.QueryString["GameTypeID"] == null)
                    {
                        lblmessage.Text = "Data Inserted Successfully.....";
                        txtGameType.Text = "";

                        txtGameType.Focus();
                    }


                    if (objConnection.State == ConnectionState.Open)
                        objConnection.Close();
                }

            }
        }
        


       // Response.Redirect("~/GameType/List");
    }
    #endregion Button : Add

    #region Button : Cancle
    protected void btncancle_ClickGameType(object sender, EventArgs e)
    {
        txtGameType.Text = "";
        
        txtGameType.Focus();
        lblmessage.Text = "";
        //Response.Redirect("");
    }
    #endregion Button : Cancle
}