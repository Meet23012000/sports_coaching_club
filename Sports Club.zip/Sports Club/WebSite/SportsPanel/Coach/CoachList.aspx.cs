﻿using SportsClub;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Sports_Panel_Coach_CoachList : System.Web.UI.Page
{
    #region Page_Load
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {

            FillCoachGrid();

        }
    }
    #endregion Page_Load

    #region FillCoach

    private void FillCoachGrid()
    {
        using (SqlConnection objConnection = new SqlConnection(DatabaseConfig.ConnectionString))
        {
            objConnection.Open();
            using (SqlCommand objcmd = objConnection.CreateCommand())
            {
                try
                {
                    #region Prepare Command
                    objcmd.CommandType = CommandType.StoredProcedure;
                    objcmd.CommandText = "PR_Coach_SelectAll";
                    //objcmd.Parameters.AddWithValue("@UserID", 1);
                    #endregion Prepare Command

                    SqlDataReader objSDR = objcmd.ExecuteReader();
                    gvCoach.DataSource = objSDR;
                    gvCoach.DataBind();

                }
                catch (Exception ex)
                {
                    lblMessage.Text = ex.Message.ToString();
                }
                finally
                {
                    if (objConnection.State == ConnectionState.Open)
                        objConnection.Close();
                }
            }
        }
    }
    #endregion FillCoach

    #region RowCommand
    protected void gvGame_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "DeleteRecord")
        {
            #region Delete Record
            Deleterecord(Convert.ToInt32(e.CommandArgument));
            FillCoachGrid();
            #endregion Delete Record
        }
    }
    #endregion RowCommand

    #region DeleteRecord
    private void Deleterecord(Int32 CoachID)
    {
        using (SqlConnection objConnection = new SqlConnection(DatabaseConfig.ConnectionString))
        {
            objConnection.Open();
            using (SqlCommand objcmd = objConnection.CreateCommand())
            {
                try
                {
                    #region prepare command
                    objcmd.CommandType = CommandType.StoredProcedure;
                    objcmd.Parameters.AddWithValue("@CoachID", CoachID);
                    objcmd.CommandText = "PR_Coach_DeletePK";
                    #endregion prepare command
                    objcmd.ExecuteNonQuery();
                }
                catch
                {
                    lblError.Text = "This Coach can't be deleted because this Coach has a Player";
                }
                finally
                {
                    if (objConnection.State == ConnectionState.Open)
                        objConnection.Close();
                }
            }
        }

    }
    #endregion DeleteRecord
}