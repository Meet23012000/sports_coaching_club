﻿using SportsClub;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Sports_Panel_Coach_CoachAddEdit : System.Web.UI.Page
{
    #region Page_load
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            FillDropDownGameName();

            if (Request.QueryString["CoachID"] != null)
            {

                loadControls(Convert.ToInt32(Request.QueryString["CoachID"].ToString()));
            }



        }

    }
    #endregion Page_load

    #region loadControls
    private void loadControls(Int32 CoachID)
    {
        using (SqlConnection objConnection = new SqlConnection(DatabaseConfig.ConnectionString))
        {
            objConnection.Open();
            using (SqlCommand objcmd = objConnection.CreateCommand())
            {
                try
                {
                    #region Prepare Command
                    objcmd.CommandType = CommandType.StoredProcedure;
                    objcmd.CommandText = "PR_Coach_SelectPK";
                    objcmd.Parameters.AddWithValue("@CoachID", CoachID);
                    #endregion Prepare Command

                    #region ReadData and Set Controls
                    SqlDataReader objSDR = objcmd.ExecuteReader();

                    if (objSDR.HasRows == true)
                    {
                        while (objSDR.Read() == true)
                        {
                            if (!objSDR["CoachName"].Equals(DBNull.Value))
                            {
                                txtCoachName.Text = objSDR["CoachName"].ToString();
                            }
                            if (!objSDR["CoachFullName"].Equals(DBNull.Value))
                            {
                                txtCoachFullName.Text = objSDR["CoachFullName"].ToString();
                            }
                            if (!objSDR["MobileNO"].Equals(DBNull.Value))
                            {
                                TxtMobileNO.Text = objSDR["MobileNO"].ToString();
                            }
                            if (!objSDR["Email"].Equals(DBNull.Value))
                            {
                                TxtEmail.Text = objSDR["Email"].ToString();
                            }
                            if (!objSDR["Address"].Equals(DBNull.Value))
                            {
                                txtAddress.Text = objSDR["Address"].ToString();
                            }

                            if (!objSDR["GameID"].Equals(DBNull.Value))
                            {
                                ddlGameName.SelectedValue = objSDR["GameID"].ToString();
                            }
                            if (!objSDR["Experience"].Equals(DBNull.Value))
                            {
                                txtExperience.Text = objSDR["Experience"].ToString();
                            }


                        }
                    }
                    #endregion ReadData and Set Controls
                }
                catch (Exception ex)
                {
                    lblmessage.Text = ex.Message.ToString();
                }
                finally
                {
                    if (objConnection.State == ConnectionState.Open)
                        objConnection.Close();
                }

            }
        }

    }
    #endregion loadControls


    #region FillDropDown GameName
    private void FillDropDownGameName()
    {
        using (SqlConnection objConnection = new SqlConnection(DatabaseConfig.ConnectionString))
        {

            objConnection.Open();
            using (SqlCommand objcmd = objConnection.CreateCommand())
            {
                try
                {
                    #region Prepare   Command
                    objcmd.CommandType = CommandType.StoredProcedure;
                    objcmd.CommandText = "PR_Game_SelectDropDownList";
                    //objcmd.Parameters.AddWithValue("@UserID", 1);
                    #endregion Prepare   Command

                    #region Read Date
                    ddlGameName.Items.Insert(0, new ListItem("-----Select GameName-----"));
                    ddlGameName.Items[0].Attributes.Add("Disabled", "true");
                    ddlGameName.Items[0].Attributes.Add("Selected", "true");

                    SqlDataReader objSDRGameName = objcmd.ExecuteReader();
                    ddlGameName.DataSource = objSDRGameName;

                    ddlGameName.DataTextField = "GameName";
                    ddlGameName.DataValueField = "GameID";
                    ddlGameName.DataBind();
                    #endregion Read Date
                }
                catch (Exception ex)
                {
                    lblmessage.Text = ex.Message.ToString();
                }
                finally
                {
                    if (objConnection.State == ConnectionState.Open)
                        objConnection.Close();
                }
            }
        }
    }
    #endregion FillDropDown GameName


    #region Button : Add
    protected void btnadd_ClickCoach(object sender, EventArgs e)
    {
        #region Local Variables
        SqlString strCoachName = SqlString.Null;
        SqlString strCoachFullName = SqlString.Null;
        SqlString strMobileNO = SqlString.Null;
        SqlString strAddress = SqlString.Null;
        SqlString strEmail = SqlString.Null;
        SqlString strGameID = SqlString.Null;
        SqlString strExperience = SqlString.Null;
        #endregion Local Variables

        #region Server Side Validation

        string strError = "";
        if (txtCoachName.Text.Trim() == "")
            strError += " - Enter Coach Name<br />";

        if (txtCoachFullName.Text.Trim() == "")
            strError += " - Enter Coach Full Name<br />";

        if (TxtMobileNO.Text.Trim() == "")
            strError += " - Enter Mobile No<br />";

        if (txtAddress.Text.Trim() == "")
            strError += " - Enter Address<br />";

        if (TxtEmail.Text.Trim() == "")
            strError += " - Enter Email<br />";

       

        if (ddlGameName.SelectedIndex.Equals(0))
            strError += " - Enter Game Name<br />";



        if (strError.Trim() != "")
        {
            lblmessage.Text = strError;
            return;
        }

        #endregion Server Side Validation

        #region Read Data
        if (txtCoachName.Text.Trim() != "")
            strCoachName = txtCoachName.Text.Trim();

        if (txtCoachFullName.Text.Trim() != "")
            strCoachFullName = txtCoachFullName.Text.Trim();

        if (TxtMobileNO.Text.Trim() != "")
            strMobileNO = TxtMobileNO.Text.Trim();

        if (txtAddress.Text.Trim() != "")
            strAddress = txtAddress.Text.Trim();

        if (TxtEmail.Text.Trim() != "")
            strEmail = TxtEmail.Text.Trim();


        if (ddlGameName.SelectedIndex.Equals(0))
            strGameID = ddlGameName.SelectedValue;

        if (txtExperience.Text.Trim() != "")
            strExperience = txtExperience.Text.Trim();

        #endregion Read Data


        using (SqlConnection objConnection = new SqlConnection(DatabaseConfig.ConnectionString))
        {

            objConnection.Open();
            using (SqlCommand objcmd = objConnection.CreateCommand())
            {
                try
                {
                    #region Prepare Command
                    objcmd.CommandType = CommandType.StoredProcedure;

                    objcmd.Parameters.AddWithValue("@CoachName", txtCoachName.Text.Trim());
                    objcmd.Parameters.AddWithValue("@CoachFullName", txtCoachFullName.Text.Trim());
                    objcmd.Parameters.AddWithValue("@MobileNO", TxtMobileNO.Text.Trim());

                    objcmd.Parameters.AddWithValue("@Address", txtAddress.Text.Trim());
                    objcmd.Parameters.AddWithValue("@Email", TxtEmail.Text.Trim());
                    //objcmd.Parameters.AddWithValue("@GameTypeID", ddlGameType.SelectedValue);
                    objcmd.Parameters.AddWithValue("@GameID", ddlGameName.SelectedValue);
                    objcmd.Parameters.AddWithValue("@Experience", txtExperience.Text.Trim());


                    if (Request.QueryString["CoachID"] == null)
                    {

                        objcmd.CommandText = "PR_Coach_Insert";
                        // objcmd.Parameters.AddWithValue("@UserID", 1);
                        lblmessage.Text = "Data Added SucessuFully";
                    }
                    else
                    {
                        objcmd.CommandText = "PR_Coach_UpdateByPK";
                        objcmd.Parameters.AddWithValue("@CoachID", Request.QueryString["CoachID"].ToString());

                        // objcmd.Parameters.AddWithValue("@UserID", 1);
                        lblmessage.Text = "Data Updated SucessFully";
                    }
                    #endregion Prepare Command
                    objcmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    lblmessage.Text = ex.Message.ToString();
                }
                finally
                {
                    if (Request.QueryString["GameID"] == null)
                    {
                        txtCoachName.Text = "";
                        txtCoachFullName.Text = "";
                        TxtMobileNO.Text = "";
                        TxtEmail.Text = "";
                        txtAddress.Text = "";




                        txtExperience.Text = "";

                        txtCoachName.Focus();
                    }


                    if (objConnection.State == ConnectionState.Open)
                        objConnection.Close();
                }
            }
        }





        // Response.Redirect("~/GameType/List");
    }
    #endregion Button : Add

    #region Button : Cancle
    protected void btnCancle_ClickCoach(object sender, EventArgs e)
    {
        txtCoachName.Text = "";
        txtCoachFullName.Text = "";
        TxtMobileNO.Text = "";
        TxtEmail.Text = "";
        txtAddress.Text = "";




        txtExperience.Text = "";

        txtCoachName.Focus();
        lblmessage.Text = "";
        //Response.Redirect("");
    }
    #endregion Button : Cancle

    
}